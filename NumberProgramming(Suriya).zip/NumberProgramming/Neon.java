package NumberProgramming;

import java.util.Scanner;

public class Neon {
	static void neonNumber(int num) {
		int sq = num*num;
		int sqSum =0;
		while(sq>0) {
			sqSum += sq%10;
			sq=sq/10;
		}
		if(num==sqSum) {
			System.out.println(num +":Neon Number");
		}
		else {
			System.out.println(num +":not a Neon Number");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number: ");
		int num = sc.nextInt();
		neonNumber(num);
		sc.close();
	}
}
