package NumberProgramming;
public class DecimalToOctal {
	static void decimalToOctal(int num) {
		int temp = num;
		String Binary="";
		while(num > 0) {
			int rem = num%8;
			Binary= rem + Binary;
			num = num/8;
		}
		System.out.println("The Binary Form of the Number "+temp+" is : "+Binary);
	}
	
	public static void main(String[] args) {
		decimalToOctal(12);
	}
}
