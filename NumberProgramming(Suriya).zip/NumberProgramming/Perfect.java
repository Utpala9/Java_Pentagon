package NumberProgramming;

import java.util.Scanner;

public class Perfect {
	static int perfect(int num) {
		int sum =0;
		for(int i=1;i<num;i++) {
			if(num%i==0)sum+=i;
		}
		return sum;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = sc.nextInt();
		int factorSum = perfect(number);

		if(number==factorSum) {
			System.out.println("Given number "+number+" is a Perfect Number");
		}
		else {
			System.out.println("Given number "+number+" is not a Perfect Number");
		}
		sc.close();
	}

}
