package NumberProgramming;

import java.util.Scanner;

public class DigitsProduct {
	static int digitsProduct(int num) {
		int prod=1;
		while(num>0) {
			int rem = num%10; 
			prod = prod*rem;
			num /=10;
		}
		
		return prod;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = sc.nextInt();
		System.out.println("The Product of the Given Number " +number +" is :" +digitsProduct(number));
	sc.close();
	}
}
