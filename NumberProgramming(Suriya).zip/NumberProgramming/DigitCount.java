package NumberProgramming;
public class DigitCount {
	static int digitCount(int num) {
		int count =0;
		while(num>0) {
			num = num/10;
			count++;
		}
		return count;
	}
	public static void main(String[] args) {
		System.out.println(digitCount(1000));
		
	}
}
