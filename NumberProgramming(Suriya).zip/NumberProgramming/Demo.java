package NumberProgramming;
import java.util.Scanner;
public class Demo {
	public void evenOrOdd(int num) {
		if(num%2==0) {
			System.out.println(num+" is Even.");
		}
		else {
			System.out.println(num+" is odd.");
		}
	}
	public void divisibleBy5Or11(int num) {
		if(num%5==0 && num%11==0) {
			System.out.println(num + " is Divisible by 5 and 11.");
		}
		else {
			System.out.println(num + " is not Divisible by 5 and 11.");
		}
	}
	void upperOrLowercase(char ch) {
		if((int)ch>=65 && (int)ch<=90) {
			System.out.println("Given Character " +ch+" is in Uppercase.");
		}
		else {
			System.out.println("Given Character " +ch+" is in Lowercase.");	
		}
	}
	void vowelOrConsonant(char ch) {
		if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
			System.out.println("Given character "+ ch +"is a Vowel");
		}
		else {
			System.out.println("Given character "+ ch +" is a Consonant");
		}
	}
	void largestNum(double num1 ,double num2) {
		if(num1>num2) {
			System.out.println(num1+" is larger than "+num2);
		}else {

			System.out.println(num2+" is larger than "+num1);
		}
	}
void largestOfThreeNumber(double num1 ,double num2,double num3) {
		if(num1>num2 && num1>num3) {
			
				System.out.println(num1+" is larger than "+num2+" and "+num3);
			
		}else if(num2>num1 && num2>num3){

			System.out.println(num2+" is larger than "+num1+" and "+num3);
		}
		else {
			System.out.println(num3+" is larger than "+num1+" and "+num2);
		}
	}
	public static void main(String[] args) {
		Demo de= new Demo();
		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter a Number To check Even or Odd :");
//		int a = sc.nextInt();
//		de.evenOrOdd(a);
//		System.out.println("Enter a number to check given number is Divisible by 5 or 11 :");
//		int b = sc.nextInt();
//		de.divisibleBy5Or11(b);
//		System.out.println("Enter a character to check if it is upperCase or lowerCase:");
//		char c = sc.next().charAt(0);
//		de.upperOrLowercase(c);
//		System.out.println("Enter a character to check if it a vowel or Consonant :");
//		char d = sc.next().charAt(0);
//		de.vowelOrConsonant(d);
		System.out.println("Enter two number to check the larger number :");
		double e = sc.nextDouble();
		double f = sc.nextDouble();
		de.largestNum(e,f);
		System.out.println("Enter Three number to check the larger number :");
		double g = sc.nextDouble();double h = sc.nextDouble();double i = sc.nextDouble();
		de.largestOfThreeNumber(g,h,i);
		sc.close();
	}
}
