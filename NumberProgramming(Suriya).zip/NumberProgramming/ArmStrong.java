package NumberProgramming;
public class ArmStrong {
	static int count(int num) {
		int count=0;
		while(num>0) {
			count++;
			num/=10;
		}
		return count;
	}
	static int power(int num,int count) {
		int powerValue = 1;
		for(int i=1;i<=count;i++) {
			powerValue = powerValue *num;
		}
		System.out.println("Power value is : " +powerValue);
		return powerValue;
	}
	static void armStrong (int num) {
		int count = count(num);
		int temp = num;
		int sum =0;
		while(num>0) {
			int rem = num%10;
			sum = sum + power(rem,count);
			num/=10;
		}
		System.out.println("Sum of the powers is : "+sum );
		if(temp ==sum) {
			System.out.println("Given number "+temp +" is an ArmStrong Number.");
		}
		else {
			System.out.println("Given number "+temp +" is Not an ArmStrong Number.");
		}	
	}
	public static void main(String[] args) {
		armStrong(9474);
		
	}
}
