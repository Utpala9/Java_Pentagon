package NumberProgramming;
public class SqOfEvenNumAndCubeOfOddNum {
	
	static void sqOfEvenNumAndCubeOfOddNum(int num) {
		while(num>0) {
			int digit = num % 10;
			int rem =digit%2;
			int sq=0;
			int cube=0;
			if(rem == 0) {
				sq = digit*digit;
				System.out.println(digit + "its square is : "+ sq);
			}
			else {
				cube = digit*digit*digit;
				System.out.println(digit + "its square is : "+cube);
			}
			num=num/10;
		}
	}
	public static void main(String[] args) {
		sqOfEvenNumAndCubeOfOddNum(7);
	}
}
