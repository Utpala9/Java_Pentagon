package NumberProgramming;

import java.util.Scanner;

public class Factors {
	static void factors(int num) {
		for(int i=1;i<=num;i++) {
			if(num%i==0) {
				System.out.println(i);
			}
		}
	}
	static void factorsCount(int num) {
		int count =0;
		for(int i=1;i<=num;i++) {
			if(num%i==0) {
				count++;
			}
		}
		System.out.println("Factors count : "+count);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number to get it factors: ");
		int number = sc.nextInt();
		factors(number);
		factorsCount(number);
		sc.close();
	}
}
