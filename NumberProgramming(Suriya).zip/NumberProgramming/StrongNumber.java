package NumberProgramming;

import java.util.Scanner;

public class StrongNumber {
	static int factorial(int num) {
		int fact = 1;
		for(int i=1;i<=num;i++) {
			fact = fact * i;
		}
		return fact;
	}
	static int factorialSum(int num) {
		int factSum = 0;
		while(num>0) {        
			int rem = num%10;
			factSum =factSum +factorial(rem);
			num=num/10;
		}
		return factSum;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = sc.nextInt();
		int factSum = factorialSum(number);
		if(number == factSum) {
			System.out.println("Given number "+number+" is a Strong Number");
		}
		else {
			System.out.println("Given number "+number+" is Not a Strong Number");
		}
		sc.close();
	}
}
