package NumberProgramming;
public class DecimalToHexaDecimal {
	static char str(int num) {
		num = num +55;
		System.out.println(num);
		return (char)num;
	}
	static void decimalToHexaDecimal(int num) {
		int temp = num;
		String hexaDecimal = "";
		while(num>0) {
			int rem = num%16;
			if(rem>9) {
				hexaDecimal = (char)(rem+55)+hexaDecimal;
			}
			else {
				hexaDecimal = rem+hexaDecimal;
			}
			num/=16;
		}
		System.out.println("The Binary Form of the Number "+temp+" is : "+hexaDecimal);
	}
	public static void main(String[] args) {
		decimalToHexaDecimal(169);
	}
}
