package NumberProgramming;
public class BuzzNumber {
//divisible by 7 or remainder is seven.
	static void buzz(int num) {
		if(num%7==0 || num%10 ==7) {
			System.out.println(num +" is a Buzz number");
		}
		else {
			System.out.println(num +" is a Not a Buzz number");
		}
	}
	public static void main(String[] args) {
		buzz(70);
	}
}
