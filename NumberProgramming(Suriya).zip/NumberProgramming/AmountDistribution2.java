package NumberProgramming;
import java.util.Scanner;
public class AmountDistribution2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number :");
		int amount =sc.nextInt();
		int fiveHundreds=amount/500;
		amount=amount%500;
		int twoHundreds=amount/200;
		amount =amount%200;
		int hundreds=amount/100;
		amount =amount%100;
		int fifties=amount/50;
		amount =amount%50;
		int twenties=amount/20;
		amount =amount%20;
		int tens=amount/10;
		amount=amount%10;
		int coins =amount;
		System.out.println("Five Hundreds are :"+fiveHundreds);
		System.out.println("Two Hundreds are :"+twoHundreds);
		System.out.println("Hundreds are :"+hundreds);
		System.out.println("Fifties are :"+fifties);
		System.out.println("Twenties are :"+twenties);
		System.out.println("Tens are :"+tens);
		System.out.println("Coins are :"+coins);
		sc.close();
	}

}
