package NumberProgramming;

import java.util.Scanner;

public class AmountDistribution {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the amount :");
		int amount = sc.nextInt();
		int fiveHundreds=0;
		int twoHundreds=0;
		int hundreds=0;
		int fifties=0;
		int twenties=0;
		int tens=0;
		int fives=0;
		int twos=0;
		int ones=0;
		while(amount>0) {
			if(amount >=500) {
				fiveHundreds++;
				amount-=500;				
			}
			else if(amount>=200) {
				twoHundreds++;
				amount-=200;
			}
			else if(amount>=100) {
				hundreds++;
				amount-=100;
			}
			else if(amount>=50) {
				fifties++;
				amount-=50;
			}
			else if(amount>=20) {
				twenties++;
				amount-=20;
			}
			else if(amount>=10) {
				tens++;
				amount-=10;
			}
			else if(amount>=5) {
				fives++;
				amount-=5;
			}
			else if(amount>=2) {
				twos++;
				amount-=2;
			}
			else if(amount>=1) {
				ones++;
				amount-=1;
			}	
		}
		System.out.println("Five Hundreds are :"+fiveHundreds);
		System.out.println("Two Hundreds are :"+twoHundreds);
		System.out.println("Hundreds are :"+hundreds);
		System.out.println("Fifties are :"+fifties);
		System.out.println("Twenties are :"+twenties);
		System.out.println("Tens are :"+tens);
		System.out.println("Fives are :"+fives);
		System.out.println("Twos are :"+twos);
		System.out.println("Ones are :"+ones);
		sc.close();
		
	}
}
