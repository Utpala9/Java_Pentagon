package NumberProgramming;

import java.util.Scanner;

public class Palindrome {
	static int palindrome(int num) {
		int rev = 0;
		while(num>0) {
			rev = rev*10 + num%10;
			num /= 10;
		}
		return rev;
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = sc.nextInt();
		int reversed = palindrome(number);

		if(number==reversed) {
			System.out.println("Given number is a palindrom");
		}
		else {
			System.out.println("Given number is not a palindrom");
		}
		sc.close();
	}
}
