package NumberProgramming;
public class Automorphic {
	static void automorphic(int num) {
		int temp = num;
		int sq = num*num;
		while(num>0) {
			int fd=num%10;
			int sd=sq%10;
			if(fd==sd) {
				num/=10;
				sq/=10;
			}else {
				System.out.println(temp+" is Not an Automorphic Number");
				return;
			}
		}
		System.out.println(temp+" is an Automorphic Number");
	}
	public static void main(String[] args) {
		automorphic(25);
	}
}
