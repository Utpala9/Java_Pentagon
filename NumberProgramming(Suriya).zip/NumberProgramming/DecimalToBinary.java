package NumberProgramming;
public class DecimalToBinary {
	static void decimalToBinary(int num) {
		int temp = num;
		String Binary="";
		while(num > 0) {
			int rem = num%2;
			Binary= rem + Binary;
			num = num/2;
		}
		System.out.println("The Binary Form of the Number "+temp+" is : "+Binary);
	}
	public static void main(String[] args) {
		decimalToBinary(12);
	}
}
