package NumberProgramming;

import java.util.Scanner;

public class NaturalNumbers {
	
	public static void printNaturalNumbers(int num) {
		for(int i=1;i<=num;i++) {
			System.out.print(i+" ");
		}
	}
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Number :");
		int number =sc.nextInt();
		printNaturalNumbers(number);
		sc.close();
	}
}
