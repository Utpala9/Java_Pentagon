package NumberProgramming;

public class SumOfDigitsLeavingFirstDigit {
	static void sumOfDigitsLeavingFirstDigit(int num) {
		int sum =0;
		while(num>9) {
			sum = sum +num%10;
			num /= 10;
		}
		System.out.println("The Sum of the digits leaving the first digit : "+ sum);
		System.out.println("The last digit is : "+ num);
	}
	public static void main(String[] args) {
		sumOfDigitsLeavingFirstDigit(12345);
	}
}
