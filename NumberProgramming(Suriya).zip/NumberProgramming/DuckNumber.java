package NumberProgramming;
public class DuckNumber {
	static void duckNumber(int num) {
		int temp = num;
		while(num>9) {
			if(num%10 == 0) {
				System.out.println(temp + " is a Duck Number.");
				return;
			}
			num/=10;
		}
		System.out.println(temp + " is Not a Duck Number.");
	}
	public static void main(String[] args) {
		duckNumber(1001);
	}
}
