package NumberProgramming;

import java.util.Scanner;

public class ReversingTheNumber {
	static void reverse(int num) {
		int rev = 0;
		while(num>0) {
			rev = rev*10 + num%10;
			num /= 10;
		}
		System.out.println("The Reversed Number is : "+rev);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = sc.nextInt();
		reverse(number);
		sc.close();
	}
}