package NumberProgramming;

import java.util.Scanner;

public class Prime {
	static void isPrime(int num) {
		for(int i=2;i<=num/2;i++) {
			if(num%i==0) {
				System.out.println("Not Prime");
				return;
			}
		}
		System.out.println("Prime");
	}
	static boolean isPrime1stWay(int num) {
		int count=0;
		for(int i=1;i<=num;i++) {
			if(num%i==0) {
				count++;
			}
		}
		if(count==2)return true;
		else return false;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = sc.nextInt();
		isPrime(number);
		System.out.println(isPrime1stWay(number));
		
		sc.close();
	}
}
