package NumberProgramming;

import java.util.Scanner;

public class Factorial {
	public static void factorial(int num) {
		int result =1;
		for(int i=1;i<=num;i++) {
			result*=i;
			}
		System.out.println("The Factorial of "+num+" Natural Numbers is : "+result);	      
	}
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Number :");
		int number =sc.nextInt();
		factorial(number);
		sc.close();
	}
}
