package NumberProgramming;
public class LCM {
//	static int max(int num1,int num2) {
//		if(num1 >num2)return num1;
//		else return num2;
//	}
	static void lcm(int num1,int num2) {
		int lcmNum =num1>num2?num1:num2;
		while(true) {
			if(lcmNum%num1==0 && lcmNum%num2==0) {
				System.out.println("LCM is :"+lcmNum);
				return;
			}
			lcmNum++;
		}	
	}
	public static void main(String[] args) {
		lcm(12,18);
	}
}
