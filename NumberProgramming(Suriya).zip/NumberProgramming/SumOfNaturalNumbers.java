package NumberProgramming;

import java.util.Scanner;

public class SumOfNaturalNumbers {
	public static void sumNaturalNumbers(int num) {
		int result=0;
		for(int i=1;i<=num;i++) {
			result += i;
		}
		System.out.println("The sum of "+num+" Natural Numbers is :"+result);
	}
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Number :");
		int number =sc.nextInt();
		sumNaturalNumbers(number);
		sc.close();
	}
}
