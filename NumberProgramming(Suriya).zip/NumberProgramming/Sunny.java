package NumberProgramming;
public class Sunny {
	static void sunny(int num) {
		int next = num + 1;
		int i=1;
		int count=0;
		while(i*i<=next) {
			count++;
			if((i*i) == next) {
				System.out.println("Given number "+num+" is Sunny number. Count is : "+count);
				return;
			}
			i++;
		}
		System.out.println("Given number "+num+" is not a Sunny number. Count is : "+count);
		
	}
	public static void main(String[] args) {
		sunny(1234);
	}
}