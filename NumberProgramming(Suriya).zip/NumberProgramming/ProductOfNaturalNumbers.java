package NumberProgramming;

import java.util.Scanner;

public class ProductOfNaturalNumbers {
	public static void productNaturalNumbers(int num) {
		int result =1;
		for(int i=1;i<=num;i++) {
			result*=i;
			}
		System.out.println("The Product of "+num+" Natural Numbers is :"+result);	      
	}
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Number :");
		int number =sc.nextInt();
		productNaturalNumbers(number);
		sc.close();
	}
}
