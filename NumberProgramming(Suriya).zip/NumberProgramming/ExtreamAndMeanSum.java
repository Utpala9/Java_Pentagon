package NumberProgramming;
public class ExtreamAndMeanSum {
	static void extreamAndMeanSum(int num) {
		int extreamSum = 0;
		int meanSum = 0;
		int last = num%10;
		while(num>9) {
			meanSum = meanSum + num%10;
			num /=10;
		}
		extreamSum= num + last;
		meanSum = meanSum - last;
		System.out.println("Extream Sum : "+  extreamSum);
		System.out.println("Mean Sum : "+  meanSum);
	}
	public static void main(String[] args) {
		extreamAndMeanSum(56789);
	}
}
