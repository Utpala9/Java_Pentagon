package NumberProgramming;
public class HCF {

	static void hcf(int num1,int num2) {
		int hcfNum = num1>num2?num2:num1;
		while(hcfNum>1) {
			if(num1%hcfNum==0 && num2%hcfNum==0) {
				System.out.println("HCF is :"+hcfNum);
				return;
			}
			hcfNum--;
		}
	} 
	public static void main(String[] args) {
		hcf(12,18);
	}
}
