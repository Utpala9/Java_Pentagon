package Patterns;
public class TwentyNine {
	public static void main(String[] args) {
		int row =9;
		int space =4;
		int n=1;
		for(int i=1;i<=row;i++) {
			char ch = 'A';
			for(int j=1;j<=space;j++) {
				System.out.print(" ");
			}
			for(int k=1;k<=n;k++) {
				if(k<=n/2) {
					System.out.print(ch);
					ch++;
				}
				else {
					System.out.print(ch);
					ch--;
				}
			}
			if(i<5) {
				space--;
				n+=2;
			}
			else {
				space++;
				n-=2;
			}
			System.out.println();
		}
	}
}
