package Patterns;
public class six {
	public static void main(String[] args) {
		int row =5;
		int col = 5;
		for(int i=1;i<=row;i++) {
			for(int j=1;j<=col;j++) {
				if(j==1 || j==5 || i==j)System.out.print("* ");
				else System.out.print("  ");
			}
			System.out.println();
		}
	}
}