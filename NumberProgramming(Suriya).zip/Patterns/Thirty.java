package Patterns;
public class Thirty {
	public static void main(String[] args) {
		int row=9;
		int space =7;
		int n=1;
		for(int i=1;i<=row;i++) {
			char ch ='A';  
			for(int j=1;j<=n;j++) {
				if(j!=5)  
				System.out.print(ch);
				ch++;
			}
			for(int k=1;k<=space;k++) {
				System.out.print(" ");
			}
			for(int l=1;l<=n;l++) {
				ch--;
				System.out.print(ch);
			}
			System.out.println();
			if(i<5) {
				space-=2;
				n++;
			}
			else {
				space+=2;
				n--;
			}
		}
	}
}
