package Array_Programming;
public class MinumumElement { 
	static void minNum(int[] nums) {
		int min =nums[0];
		for(int i=1;i<nums.length;i++) {
			if(min>nums[i])min=nums[i];
		}
		System.out.println("The Minimum Element in the Given Array is : " +min);
		
	}
	public static void main(String[] args) {
		int[] nums= {1,2,3,4,5,6};
		minNum(nums);
	}
}
