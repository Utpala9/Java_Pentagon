package Array_Programming;
public class IsPalindromArray {
	
	
	static void isPalindromArrayOne(int[] nums) {
		boolean check = true;
		int first=0;
		int last =nums.length-1;
		while(first<last) {
			if(nums[first] != nums[last])check = false;
			first++;
			last--;
		}
		if(check) {
			System.out.println("Given Array is Palindrom");
		}
		else
			System.out.println("Given Array not is Palindrom");
	}
	
	
	static void isPalindromArraytwo(int[] nums) {
		int[] nums1 = new int[nums.length];
		int index =0;
		for(int i=nums.length-1;i>=0;i--) {
			nums1[index] = nums[i];
			index++;
		}
		boolean check = true;
		for(int i=0;i<nums.length;i++) {
			if(nums1[i] != nums[i])check = false;
		}
		if(check) {
			System.out.println("Given Array is Palindrom");
		}
		else
			System.out.println("Given Array not is Palindrom");
	}
	public static void main(String[] args) {
		int[] nums = {1,2,3,4,5,4,3,2,1};
		isPalindromArrayOne(nums);
		isPalindromArraytwo(nums);
	}
}
