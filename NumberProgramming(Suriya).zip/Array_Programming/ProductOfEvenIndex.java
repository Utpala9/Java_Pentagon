package Array_Programming;
public class ProductOfEvenIndex {
	public static void main(String[] args) {
		int[] nums = {10,20,30,40,50};
		int product =1;
		for(int i=0;i<nums.length;i++) {
			if(i%2==0) product*=nums[i];
		}
		System.out.println("The Even Index Product : "+product);
	}
}
