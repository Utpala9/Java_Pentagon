package Array_Programming;
public class EvenElementsInArray {
	static void evenCount(int[] nums) {
		int count = 0;
		for(int i=0;i<nums.length;i++) {
			if(nums[i]%2 == 0)count++;
		}
		System.out.println("The Even Count is : "+count);
	}
	public static void main(String[] args) {
		
		int[] nums = {1,2,3,4,5,6,7};
		evenCount(nums);
		
	}
	
}
