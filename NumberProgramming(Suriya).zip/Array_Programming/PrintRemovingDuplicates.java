package Array_Programming;
public class PrintRemovingDuplicates {
	static void printRemovingDuplicates(int[] nums) {
		
		for(int i=0;i<nums.length;i++) {
			int count = 0;
			for(int j=i;j<nums.length;j++) {
				if(nums[i]==nums[j])count++;
			}
			if(count == 1)System.out.println(nums[i]);
		}
	}
	public static void main(String[] args) {
		int[] nums = {10,20,30,10,30,40,30,10};
		printRemovingDuplicates(nums);
	}
}
