package Array_Programming;
public class EvenIndexElements {
	public static void main(String[] args) {
		int[] nums = {10,20,30,40,50};
		for(int i=0;i<nums.length;i++) {
			if(i%2 == 0) {
				System.out.println(nums[i]);
			}
		}
		for(int i=0;i<nums.length;i+=2) {
			System.out.println(nums[i]);
		}
	}
}
