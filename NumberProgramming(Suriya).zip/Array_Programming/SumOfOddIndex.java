package Array_Programming;
public class SumOfOddIndex {
	public static void main(String[] args) {
		int[] nums = {10,20,30,40,50};
		int sum =0;
		for(int i=0;i<nums.length;i++) {
			if(i%2!=0) sum+=nums[i];
		}
		System.out.println("The Odd Index sum : "+sum);
	}
}
