package Array_Programming;
public class MinFirstHalfMaxSecondHalf {
	static void minOfFirstHalf(int[] arr) {
		int min=arr[0];
		int mid = arr.length%2==0?arr.length/2:arr.length/2+1;
		for(int i=1;i<mid;i++) {
			if(min>arr[i])min=arr[i];
		}
		System.out.println("The Min value : "+min);
	}
	
	static void maxOfSecondHalf(int[] arr) {
		
		int mid = arr.length%2==0?arr.length/2:arr.length/2+1;
		int min=arr[mid];
		mid++;
		for(int i=mid;i<arr.length;i++) {
			if(min<arr[i])min=arr[i];
		}
		System.out.println("The Max value : "+min);
	}
	public static void main(String[] args) {
		int[] arr = {8,7,6,10,3,4,5,6,1,10,7,8};
		minOfFirstHalf(arr);
		maxOfSecondHalf(arr);
	}
}
