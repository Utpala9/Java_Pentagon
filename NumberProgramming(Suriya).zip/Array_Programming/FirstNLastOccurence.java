package Array_Programming;
public class FirstNLastOccurence {
	static void firstNLastOccurence(int[] nums,int target) {
		int firstIndex =-1;
		int lastIndex =-1;
		for(int i=0;i<nums.length;i++) {
			if(nums[i] == target) {
				firstIndex = i;
				break;
			}
		}
		for(int i=0;i<nums.length;i++) {
			if(nums[i] == target) {
				lastIndex = i;
			}
		}
		System.out.println("The First Index : " + firstIndex);
		System.out.println("The Last Index : " + lastIndex);
	}
	public static void main(String[] args) {
		int[] nums = {10,20,30,18,18,18,30};
		firstNLastOccurence(nums, 18);
	}
}
