package Array_Programming;

public class CreateStoreAccess {
	public static void main(String[] args) {
		int[] arr1 = {1,2,3,4,5};
		int[] arr2 = new int[5];
		
//		store
		arr2[0] =10;
		arr2[1] =20;
		arr2[2] =30;
		
//		access
		System.out.println(arr1[0]);
		System.out.println(arr2[1]);
		System.out.println(arr2[2]);
		System.out.println(arr2[-1]);
		
//		length 
		System.out.println(arr2.length);
		
//		using length accessing last element
		System.out.println(arr1[arr1.length-1]);
//		printing all elements in an array
		for(int i=0;i<arr1.length;i++) {
			System.out.println(arr1[i]);
		}
	}
}
