package Array_Programming;

import java.util.Arrays;

public class ReversingFirstHalf {
	public static void main(String[] args) {
		int[] nums = {10,20,30,40,50,60,70,80};
		int mid = nums.length%2==0?nums.length/2:nums.length/2+1;
		System.out.println(mid);
		int first = 0;
		mid--;
		while(first < mid) {
			int temp = nums[first];
			nums[first]=nums[mid];
			nums[mid]=temp;
			first++;
			mid--;
		}
		System.out.println(Arrays.toString(nums));
	}
}
