package Array_Programming;
public class SumFirstHalfProductSecondHalf {
	
	public static void main(String[] args) {
		int[] nums = {1,2,3,4,5,6,7};
		int length = nums.length;
		int mid =0;
		if(length%2==0)mid = length/2;
		else mid = length/2 + 1;
		int sum =0;
		for(int i=0;i<mid;i++) {
			sum +=nums[i];
		}
		int product =1;
		for(int i=mid;i<length;i++) {
			product *=nums[i];
		}
		System.out.println("Sum Of first half : "+sum);
		System.out.println("Product Of Second half : "+product);
		
	}
}
