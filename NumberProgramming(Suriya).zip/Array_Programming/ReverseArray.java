package Array_Programming;
public class ReverseArray {
	public static void main(String[] args) {
		int[] arr = {1,2,3,4,5,6};
		int i=0;
		int j=arr.length-1;
		
		System.out.print("Normal Array : ");
		for(int k=0;k<arr.length;k++) {
			System.out.print(arr[k]+" ");
		}
		
		while(i<j) {
			int temp = arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
			i++;
			j--;
		}
		
		System.out.print("Reversed Array : ");
		for(int k=0;k<arr.length;k++) {
			System.out.print(arr[k]+" ");
		}
	}
}
