package Array_Programming;

import java.util.Arrays;

public class ReversingSecondHalf {
	public static void main(String[] args) {
		int[] nums = {10,20,30,40,50,60,70,80};
		int mid = nums.length%2==0?nums.length/2:nums.length/2+1;
		int last = nums.length-1;
		while(mid<last) { 
			int temp = nums[mid];
			nums[mid] = nums[last];
			nums[last] = temp;
			mid++;
			last--;
		}
		System.out.println(Arrays.toString(nums));
	}
}
