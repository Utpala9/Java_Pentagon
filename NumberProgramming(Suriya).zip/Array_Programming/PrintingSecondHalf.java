package Array_Programming;
public class PrintingSecondHalf {
	public static void main(String[] args) {
		int[] nums = {1,2,3,4,5,6,7};
		int length = nums.length;
		int mid =0;
		if(length%2==0)mid = length/2;
		else mid = length/2 + 1;
		for(int i=mid;i<length;i++) {
			System.out.print(nums[i]+" ");
		}
	}
}
